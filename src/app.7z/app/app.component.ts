import { Component, OnInit } from '@angular/core'
import { Product } from './product.model'
      
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

      
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'inventory-app',
  template: `


  <select [(ngModel)]="selectedCurrency" name="first">
        <option *ngFor="let o of options">
          {{o.name}}
        </option>
      </select>

<div></div>
<br/>

<div class="price">{{convertWithCurrencyRate(555, selectedCurrency) 
     | currency:selectedCurrency:true:'3.2-2'}}</div>

<p>selectedCurrency: {{ selectedCurrency }}</p>

  <div class="inventory-app">
  <product-list
    [productList]="products"
    (onProductSelected)="productWasSelected($event)">
  </product-list>
</div>

`,
  styleUrls: [ './app.component.css' ]
})
@Injectable()
export class AppComponent implements OnInit  {
  products: Product[]

  constructor(private http: HttpClient) {
    this.products = [
      new Product(
        'A-01',
        'Adidas UltraBOOST',
        './assets/image.png',
        ['Men', 'Shoes', 'Running Shoes'],
        260
      ),
      new Product(
        'N-01',
        'Nike Air Max',
        'https://ugc.nikeid.com/is/image/nike/ugc/287164203.tif',
        ['Men', 'Shoes', 'Running Shoes'],
        270
      )   ,
      new Product(
        'N-02',
        'Nike Air Max2',
        'https://ugc.nikeid.com/is/image/nike/ugc/287164203.tif',
        ['Men', 'Shoes', 'Running Shoes'],
        270
      )      
    ]
  }  
  ngOnInit(): void {
  }

  productWasSelected(halo: Product): void {
    console.log('Product clicked: ', halo);
  }

  selectedOption: string;
  selectedCurrency = 'USD';
  printedOption: string;

  options = [
    { name: "INR", value: 1, currencyRate: 25 },
    { name: "USD", value: 2, currencyRate: 15 },
    { name: "CLP", value: 3, currencyRate: 35 }
  ]

  convertWithCurrencyRate(value: number, currency: string){
    let currencyRate = this.options.find(f=> f.name === currency).currencyRate;
  //   var val =this.getConfig().subscribe((data: any) =>  {
  //     console.log(data);
  //     console.log("VAlueeeeeeeeeeee:"+data.rates['USD']);
  // });;
    if (currencyRate)
      return value * currencyRate;
    
    return value;
  }
  print() {
    this.printedOption = this.selectedOption;
    console.log("My input: ", this.selectedOption);
  }
  getConfig() {
    return this.http.get('https://api.exchangeratesapi.io/latest?base=INR');
  }
}
  